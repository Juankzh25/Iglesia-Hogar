---
name: Sacred Grace
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45474c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#555e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#121b2e'
  on-primary-container: '#7a849a'
  inverse-primary: '#bdc6df'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#0d1c2d'
  on-tertiary-container: '#768599'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2fc'
  primary-fixed-dim: '#bdc6df'
  on-primary-fixed: '#121b2e'
  on-primary-fixed-variant: '#3d475b'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#d4e4fa'
  tertiary-fixed-dim: '#b9c8de'
  on-tertiary-fixed: '#0d1c2d'
  on-tertiary-fixed-variant: '#39485a'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: auto
  max-width: 1200px
---

## Brand & Style

The brand personality of this design system is rooted in reverence, hospitality, and structural clarity. It is designed to evoke a sense of peace and spiritual grounding, balancing the weight of tradition with the accessibility of modern community. The target audience includes a diverse multigenerational congregation, requiring an interface that is both dignified for elder members and intuitive for younger users.

The visual style follows a **Minimalist-Modern** approach with **Corporate** reliability. It utilizes expansive white space to represent clarity and "breathing room" for reflection. The aesthetic is punctuated by high-quality typography and a disciplined use of color, ensuring that the message—whether it be scripture, events, or community news—remains the central focus.

## Colors

The palette is anchored by a **Deep Navy** (#0C1628) pulled directly from the logo, symbolizing depth, stability, and the night sky. This is the primary color for backgrounds of high importance, navigation bars, and primary text.

- **Primary (Deep Navy):** Used for primary actions, headers, and branding elements.
- **Secondary (Muted Gold):** Used sparingly as an accent for spiritual highlights, active states, or special calls to action to provide warmth and a sense of "divine" value.
- **Tertiary (Silver/Slate):** A cool gray used for secondary icons, borders, and metadata.
- **Neutral (Cloud White):** The foundation for surfaces, providing a clean and welcoming backdrop that ensures maximum readability.

The default mode is **Light**, emphasizing an airy, daytime sanctuary feel, though the Deep Navy is used for "Hero" sections to create high-contrast, impactful moments.

## Typography

This design system employs a sophisticated typographic pairing to reflect the intersection of the ancient and the modern. 

**Playfair Display** is used for all headlines. Its high-contrast serifs and elegant terminals provide a "literary" and authoritative feel, perfect for scripture quotes and section titles. 

**Manrope** is used for all functional text, including body copy, labels, and inputs. It was chosen for its modern, balanced proportions and exceptional legibility across digital devices. 

To maintain the organized nature of the brand, use `label-lg` with uppercase styling for category headers and overlines. Ensure generous line heights in body text to facilitate comfortable reading of long-form content such as devotionals or sermons.

## Layout & Spacing

The layout philosophy centers on a **Fixed Grid** for desktop and a **Fluid Grid** for mobile. The system uses a strict 8px spatial scale to maintain mathematical harmony.

- **Desktop:** A 12-column grid with a maximum container width of 1200px. Gutters are fixed at 24px to provide clear separation between content blocks.
- **Mobile:** A 4-column fluid grid with 16px side margins. 
- **Spacing Rhythm:** Use large vertical padding (`xl`) between major sections to reinforce the minimalist and organized personality. Content should never feel crowded; prioritize white space to encourage a calm user experience.

Elements should be aligned to the grid, but decorative elements (like the star icon or silver lines from the logo) may occasionally break the grid to add visual interest.

## Elevation & Depth

Visual hierarchy in this design system is achieved through **Tonal Layers** and **Low-contrast Outlines** rather than heavy shadows. This keeps the interface feeling "light" and ethereal.

- **Surface Tiers:** Use the primary Navy for the highest level of importance (e.g., App Bar). Use the Neutral off-white for the main background, and pure White for card surfaces.
- **Outlines:** Use 1px solid strokes in the Tertiary color (#94A3B8) or a lighter silver for cards and input fields. This mimics the silver horizontal lines found in the church logo.
- **Shadows:** When depth is absolutely necessary (such as on floating action buttons or menus), use a "soft glow" shadow: very low opacity (5-8%) with a large blur radius (20px+) and no offset, creating a subtle lift rather than a harsh drop-off.

## Shapes

The shape language is **Soft** and intentional. While the brand is organized and traditional, sharp corners can feel overly clinical or aggressive. A subtle 4px radius (Level 1) is applied to standard components to soften the interface while maintaining a sense of structural integrity.

- **Standard Buttons/Inputs:** 4px radius.
- **Cards/Containers:** 8px radius (`rounded-lg`).
- **Feature Modals:** 12px radius (`rounded-xl`).

Circular shapes should be reserved exclusively for avatars or specific decorative "sparkle" elements to maintain the system's clean, rectilinear foundation.

## Components

### Buttons
Primary buttons use the Deep Navy background with White text. Secondary buttons use a Silver outline with Navy text. For "Spiritual Actions" (e.g., Give, Pray, Join), use the Gold accent as the background color to denote a special category of interaction.

### Cards
Cards are white with a subtle 1px silver border. They should have generous internal padding (24px) and use the `headline-md` for titles.

### Input Fields
Inputs should be clean with a bottom-border only or a very light silver frame. Focus states should transition the border color to the Deep Navy.

### Lists
Lists (for sermons or scripture) should use horizontal dividers in light silver. The "Play" or "Read" icons should use the Gold accent color.

### Chips/Tags
Used for sermon topics or event categories. These should be low-contrast (light gray background with navy text) to avoid distracting from the main content.

### Dividers
Drawing inspiration from the logo, use thin, centered horizontal silver lines to separate major content themes within a page.